﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GilesTrinity.Settings.Loot
{
    [Flags]
    public enum TrinityGemType
    {
        Emerald,
        Topaz,
        Amethys,
        Ruby
    }
}
