﻿
namespace GilesTrinity.Settings.Loot
{
    public enum ItemFilterMode
    {
        TrinityOnly,
        TrinityWithItemRules,
        DemonBuddy
    }
}
