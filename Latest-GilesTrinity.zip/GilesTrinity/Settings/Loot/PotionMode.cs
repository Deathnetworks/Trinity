﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GilesTrinity.Settings.Loot
{
    public enum PotionMode
    {
        All = 1, 
        Cap = 2,
        Ignore = 3
    }
}
