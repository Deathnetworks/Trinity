﻿
namespace GilesTrinity.Settings.Loot
{
    public enum TrashMode
    {
        Salvaging,
        Selling
    }
}
