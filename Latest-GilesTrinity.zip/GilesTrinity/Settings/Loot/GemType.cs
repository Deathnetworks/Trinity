﻿using System;

namespace GilesTrinity.Settings.Loot
{
    [Flags]
    public enum TrinityGemType
    {
        Emerald = 1,
        Topaz = 2,
        Amethyst = 4,
        Ruby = 8
    }
}
