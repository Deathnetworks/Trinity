﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GilesTrinity
{
    public enum AvoidanceType
    {
        Arcane,
        Desecrator,
        MoltenTrail,
        MoltenCore,
        PoisonTree,
        PlagueCloud,
        IceBall,
        PlagueHand,
        BeeWasp,
        AzmodanPool,
        AzmodanFireball,
        AzmodanBody,
        Belial,
        ShamanFire,
        GhomGas,
        DiabloRingOfFire,
        ButcherFloorPanel,
        MaghdaProjectille,
        ZoltTwister,
        ZoltBubble,
        WallOfFire,
        MoltenBall,
        IceTrail,
        DiabloMeteor,
        DiabloPrison,
        MageFire
    }
}
