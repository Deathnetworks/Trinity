﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GilesTrinity.Settings.Combat
{
    public enum GoblinPriority
    {
        Ignore = 0,
        Normal = 1,
        Prioritize = 2,
        Kamikaze = 3
    }
}
